x = [int(x) for x in input("Introduce 8 numeros: ").split(",")]
print("Los números introducidos son: ", x )
for num in x:
    impar = (num % 2 != 0)
    if impar == True:
        print(num, end=' ')











